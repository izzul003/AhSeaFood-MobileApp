import { Sizes } from '../../../configs';

export default {
  container: {
    flex: -1,
    paddingHorizontal: Sizes.screen.paddingHorizontal,
  },
};
