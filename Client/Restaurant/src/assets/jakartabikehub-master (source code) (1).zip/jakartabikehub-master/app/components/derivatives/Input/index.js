import InputString from './InputString';
import InputPhone from './InputPhone';

export { InputString, InputPhone };
