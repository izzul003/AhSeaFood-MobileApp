import TextXL from './TextXL';
import TextXLX from './TextXLX';
import TextL from './TextL';
import TextLX from './TextLX';
import TextM from './TextM';
import TextMX from './TextMX';
import TextS from './TextS';
import TextSX from './TextSX';

export { TextL, TextLX, TextM, TextMX, TextS, TextSX, TextXL, TextXLX };
