import { Colors } from '../../../configs';

export default {
  main: {
    flex: -1,
    fontSize: 24,
    color: Colors.main.baseBlack,
  },
};
