import Colors from './Colors';
import Sizes from './Sizes';
import Images from './Images';

export { Colors, Sizes, Images };
