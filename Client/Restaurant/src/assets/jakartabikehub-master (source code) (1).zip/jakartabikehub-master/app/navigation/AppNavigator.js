import { createStackNavigator, createAppContainer } from 'react-navigation';
import Load from '../modules/main/Load';
import Landing from '../modules/main/Landing';
import Home from '../modules/main/Home';
import Login from '../modules/auth/Login';
import Register from '../modules/auth/Register';
import Main from '../modules/main/Main';

const AppNavigator = createStackNavigator(
  {
    Load: { screen: Load },
    Landing: { screen: Landing },
    Home: { screen: Home },
    Login: { screen: Login },
    Register: { screen: Register },
    Main: { screen: Main },
  },
  {
    initialRouteName: 'Load',
    headerMode: 'none',
  }
);

export default createAppContainer(AppNavigator);
