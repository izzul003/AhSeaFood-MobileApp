import Firebase from 'react-native-firebase';

export const Analytics = Firebase.analytics();
export const Crashlytics = Firebase.crashlytics();
