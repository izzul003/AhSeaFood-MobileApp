export default {
  hello: 'Hello',
  skip: 'Lewati',
  welcome_to_jakBikeHub_feel_free_and_enjoy_your_ride_with_simple_way:
    'Selamat datang di JakBikeHub, rasakan kebebasan dan nikmati perjalanan Kamu dengan cara sederhana',
  register_your_account_take_a_picture_of_your_ID_Card:
    'Daftarkan akun anda. Ambil gambar KTP Anda',
  find_nearest_shelter_from_your_location_choose_one_and_Unlock_it:
    'Temukan pos terdekat dari lokasi Anda, pilih satu dan Buka kunci!',
  Enjoy_and_have_fun: 'Nikmati dan bersenang senanglah !',
  SIGN_IN: 'MASUK',
  REGISTER: 'DAFTAR',
  Hi_welcome_back_Please_fill_your_login_details:
    'Hai, selamat datang kembali! Silakan isi detail data Kamu',
  Phone_Number_or_Email: 'Nomor Telepon atau Surel',
  Enter_Password: 'Masukkan Kata Kunci',
  Cannot_be_Empty: 'Tidak boleh kosong',
  server_busy: 'Oops server sedang sibuk, silahkan coba kembali',
};
